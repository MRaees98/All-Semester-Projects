import React from "react";

//import resumeSvg from "../../assets/resume.svg";

import styles from "./Header.module.css";

function Header() {
  
}

export default Header;
