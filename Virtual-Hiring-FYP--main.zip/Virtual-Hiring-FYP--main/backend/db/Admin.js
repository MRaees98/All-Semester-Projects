const mongoose = require("mongoose");
//const { default: App } = require("../../frontend/src/App");

let schema = new mongoose.Schema(
  {
    AdminId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      unique :true
    },
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password:{
      type: String,
      required: true,
      },
    type:{
      type:String,
      required: true,
      
    },
  }
);
// const AdminAuth = mongoose.model('Adminauth', schema);

const Request = async(req,res) =>{
  const Admin = new AdminAuth(req.body);
  const admin = await Admin.save();
  res.json(admin);
}
 
module.exports = mongoose.model("Adminauth", schema);
